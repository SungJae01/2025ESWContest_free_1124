# 창의적 공학설계 [2025.03.12 ~ 2025.11.--]


**수원대학교 졸업작품**

- 자기주도역량 : 졸업작품의 기획단계부터 본인이 주도적으로 참여하여 이후 개발, 평가, 발표를 진행하여야 함.
- 전문역량 : 학과의 커리큘럼에 따른 전공 과목에서 습득한 지식을 바탕으로 졸업 작품을 개발하여야 함.
- 창의역량 : 답이 없는 문제를 정의하고 그 문제를 풀어가기 위해 본인의 창의성을 최대한 발휘하여야 함.

👨🏻‍🏫 **담당 교수님** : 김시현 [정보통신학부]

🙋🏻‍♂️ **팀원** : 박성재 [20], 심성관 [20]

# 주제 : 🎤 Voice Authentication Smart System (ECAPA-TDNN + Wav2Vec2 + Pitch Ensemble)

> 화자 인식을 기반으로 한 개인화 보안 시스템  
> 프로필 생성부터 자동 로그인, 2차 인증, AI 음성 탐지까지!

---

## 🧠 프로젝트 개요

이 프로젝트는 사용자의 **고유한 음성 특징**을 바탕으로 스마트 도어락, 홈 IoT 등의 보안 시스템에 응용 가능한 **음성 기반 인증 시스템**입니다.  
**ECAPA-TDNN**과 **Wav2Vec2 + Pitch 임베딩**을 앙상블하여 **높은 정확도와 강건성**을 확보하고, **Silero VAD**를 통해 **무음/잡음 필터링** 기능을 추가해 **신뢰도 높은 음성 수집**을 실현했습니다.

---

## ✨ 주요 기능

| 기능 | 설명 |
|------|------|
| 👤 프로필 생성 | 10~15초 문장 5개를 녹음해 음성 임베딩 생성 |
| ~~🗑️ 프로필 삭제~~ | ~~UI에서 바로 삭제 가능~~ |
| 🔐 출입 인증 | 녹음된 음성과 등록된 프로필을 비교해 출입 |
| ✅ 보안성 증가 | 랜덤 문장을 말함으로써 인증 신뢰도 향상 |
| 🤖 AI 음성 탐지 | 합성 음성(TTS, Deepfake)을 차단 |
| 🧏‍♂️ **Silero VAD 기반 녹음 필터링** | 사용자의 음성만 추출하여 임베딩 값 저장 |
| ~~🎨 넷플릭스 스타일 UI~~ | ~~직관적인 사용자 인터페이스 구현 (PyQt5)~~ |

---

## 🧱 사용된 기술

- **PyTorch**, **SpeechBrain (ECAPA-TDNN)**
- **Transformers** (`facebook/wav2vec2-base`)
- **Librosa** (Pitch 추출)
- **Silero VAD** (무음 감지 및 필터링)
- **PyQt5** (GUI)
- **Sounddevice**, **Soundfile** (녹음/저장)
- **whisper** (음성 텍스트 변환)
- **sbert** (텍스트 의미 유사도 측정 `all-MiniLM-L6-v2`)

---

## 📁 프로젝트 구조

```
📦 voice-auth-system/
 ┣ profiles/                             # 사용자 프로필 폴더
 ┣ ai_detector.py                        # AI 음성 탐지기 (ResNet 기반)
 ┣ voice_doorlock_single_auth_ver.py     # 메인 UI 및 기능 코드 (단일 인증 과정)
 ┣ voice_doorlock_double_auth_ver.py     # 메인 UI 및 기능 코드 (이중 인증 과정)
 ┣ ecapa_model/               # ECAPA 모델 저장 경로
 ┣ README.md                  # 프로젝트 설명
```

---

## 🚀 실행 방법

```bash
# 1. 필요한 라이브러리 설치
pip install -r requirements.txt

# 2. 프로젝트 실행
python voice_login_main.py
```

requirements.txt 파일 읽어보기

---

## 🛡️ 보안 구조

1. **1차 인증**: 등록된 음성과 새로 녹음한 음성 비교
2. **2차 인증**: 무작위 문장 발화 후 유사도 재검사
3. **AI 탐지**: 기계적으로 합성된 음성 탐지 및 차단
4. **음성 검증(VAD)**: 무성 음성(무음, 잡음 등) 필터링 → 유효한 음성만 프로필 생성에 사용
5. **임베딩 데이터 업데이트** : 로그인시 사용된 음성 파일을 개인 프로필 임베딩 값에 업데이트하여 매번 인증이 보안을 강화

---

## 🗣️ 프로필 생성 시 녹음 문장 예시

```
음성으로 문을 열겠습니다. 지금부터 인증을 시작합니다.
이 문장을 정확히 말하면 잠금장치가 해제됩니다.
지금 들리는 이 목소리는 저만 사용할 수 있는 보안 열쇠입니다.
스마트 도어 시스템을 통해 집에 안전하게 들어가고 싶습니다.
이제 제 음성으로 문을 열 수 있는 시대가 왔습니다. 열어주세요.
```

---

## 📌 개발 히스토리 요약

- 🔸 ECAPA-TDNN + Cosine Similarity 기반 1차 구현
- 🔸 Wav2Vec2 + Pitch 임베딩 추가 (앙상블 구조 적용)
- 🔸 긴 문장 5개 녹음 → 평균 임베딩 저장
- 🔸 디스플레이 UI 구성
- 🔸 2차 인증 및 AI 합성 음성 차단 기능 (개발중...)
- 🔸 Silero VAD 적용으로 유효 음성 자동 검출 기능 추가
- 🔸 sbert 모델 사용으로 렌덤 문장 의미 유사도 판단
- 🔸 사용자의 편리성을 위해 1차, 2차 인증과정 통합 버전

---

## 📱디스플레이 화면

# 1,2차 인증 과정 (16s ~ 20s)

순서도 -> [Flowchart](https://github.com/SungJae01/Voice-auth-system/blob/main/voice-first_second_auth-flowchart.mermaid)

https://github.com/user-attachments/assets/6a339c14-5bdc-4358-a900-dffc4742653d

- 사용자가 도어락 앞에 서면 사용자를 감지
- 1차 인증 : "문열어", "열어", "열려라 참깨" 등(아무말) 사용자의 음성을 녹음하여 화자 구별
- 2차 인증 : 1차 인증으로 프로필에 있는 사용자가 식별되면 『오늘도 좋은 하루 되세요.』 등 과 같은 렌덤한 문구 제공
- 모든 인증 과정이 완료되면 도어락 개방

# 통합 인증 과정 (8s ~ 12s)

순서도 -> [Flowchart](https://github.com/SungJae01/Voice-auth-system/blob/main/voice-auth-single-flowchart.mermaid)

https://github.com/user-attachments/assets/e9669f07-3d74-427c-9c9a-4c5a1aa7f447

- 사용자가 도어락 앞에 서면 사용자를 감지
- 『오늘도 좋은 하루 되세요.』 등 과 같은 렌덤한 문구 제공
- 인증이 완료되면 도어락 개방
- 인증 기회는 3회
- 3회 실패시 30초 동안 인증 불가
  
# 유사도 측정 과정
  <img width="879" height="261" alt="image" src="https://github.com/user-attachments/assets/c648c1e0-15aa-4789-b1e9-a40c2c30eca0" />

  
- 실제 렌덤 문장 의미 유사도 + 프로필 유사도 인증 과정

# ⚙️ NodeMCU
## 오픈소스 사물인터넷 (IoT) 플랫폼으로 와이파이 기능이 구현된 MCU 개발보드

<img width="750" height="422" alt="ESP8266-12E-NodeMCU-kit-development-board" src="https://github.com/user-attachments/assets/b7a692d2-da7a-48ef-a0cd-94914df1a5ea" />

코드 [voice_doorlock_nodeMCU.ino](https://github.com/SungJae01/Voice-auth-system/blob/main/voice_doorlock_nodeMCU/voice_doorlock_nodeMCU.ino)

보드 D6 핀으로 릴레이를 제어

![circuit diagram](https://github.com/user-attachments/assets/c4b835f7-0a1c-4143-878f-2ac0a093ebd8)

# 시연 영상

https://github.com/user-attachments/assets/0bf58e9b-a54f-4728-800c-5bf2837369c7

https://github.com/user-attachments/assets/73b977b0-84e9-4e3a-8f0e-60355e667f43

## 🙋‍♂️ 개발자

- 👨‍💻 박성재, 심성관 | 정보통신학과 4학년
- 🎓 졸업 작품으로 진행  
- ✉️ [miamo0426@gmail.com]
- 📝 [개발 메모장](https://docs.google.com/document/d/1E5yThehOcIESbAIq4tZq2XeCy7G4xBIGsNDsIICj2ls/edit?usp=sharing) 

---

## 📌 향후 확장 방향 (Ideas)

- 📱 라즈베리파이 연동
- 🧠 GPT 기반 대화형 음성 비서 결합
- 🔐 보안성 강화
- 1차 인증, 2차 인증 과정 합치기 (시간 단축)
